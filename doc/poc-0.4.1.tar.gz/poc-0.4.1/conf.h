/*C
  (c) 2003 Institut fuer Telematik, Universitaet Karlsruhe
**/

#ifndef CONF_H__
#define CONF_H__

#ifdef __linux__
#define NEED_GETOPT_H__
#endif /* linux */

#ifdef __APPLE__
#endif /* __APPLE__ */

/*C
**/

#endif /* CONF_H__ */
