#ifndef ADU_H__
#define ADU_H__

#include "mp3.h"

typedef mp3_frame_t adu_t;

#endif /* ADU_H__ */
